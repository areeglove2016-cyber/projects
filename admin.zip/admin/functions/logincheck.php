<?php
session_start();
$user=$_POST['username'];
$pass=$_POST['password'];
// $priv=$_POST['priv'];
include "connect.php";
$check = "SELECT * FROM users WHERE  username='$user' AND password='$pass' ";
$query = $conn -> query($check);
 if($query -> num_rows > 0){
    $user = $query-> fetch_assoc();
    $id=$user['id'];
    $_SESSION['loginid']=$id;
   //  $_SESSION['priv']=$priv;
    header('location:../index.php');
 }else{
    $_SESSION['loginerror']="<div class='alert alert-danger'> uncorrect login </div>";
    header('location:../login.php');
 }
?>