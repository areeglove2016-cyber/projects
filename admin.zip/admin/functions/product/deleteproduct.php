<?php
include "../connect.php";
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $delimag="DELETE FROM images WHERE product_id= $id "; 
    $querys = $conn -> query($delimag);
 $del="DELETE FROM products WHERE id=$id"; 
 $querydel= $conn->query($del);
    if( $querydel){
    header('location:../../products.php');
}else{
    echo $conn-> error ;
}}
?>