<?php

$i=0;
foreach($_FILES['imagename']['name'] as $key => $imgname){
    $i++;
    $temp=$_FILES['imagename']['tmp_name'][$key];
    $div = explode('.', $imgname);
    $file_ext = strtolower(end($div));
    $unique_image = md5(time()).'.'.$file_ext;
    $extension=['jpg','png','gif','jpeg'];
   
if(in_array($file_ext,$extension))
{
    echo "<span class='error'>You can upload only:-".implode(' .', $extension)."</span>";
    if($_FILES['imagename']['size'][$key]< 1048567){
        
            
       move_uploaded_file($temp, "../../images/$unique_image");

   
    }else{
        echo"the file is big";
        exit();
            }
}else{
    echo "wrong extension ";
    exit();
}
$insert= "INSERT INTO images
          (imagename,product_id) 
             VALUES 
             ('$unique_image', '$last_id')";
            $query = $conn -> query($insert);
      if($query){
        header('location:../../products.php');
    }else{
        echo $conn-> error ;
    }

}
   






       
        


    
            








    







/*
include_once("../connect.php");

if (isset($_POST['upload'])) {
    
    // تحديد مسار التحميل
    $uploadDir = 'images/';
    
    // التأكد من وجود المجلد، وإنشاءه إذا كان غير موجود
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    $images_nm = $_FILES['imagename']['name'];
    $target_file = $uploadDir . basename($images_nm);
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
    $extensions = array("jpg", "jpeg", "png");

    // التأكد من امتداد الملف
    if (in_array($imageFileType, $extensions)) {
        
        // التأكد من حجم الملف (أقل من 2 ميجا بايت مثلاً)
        if ($_FILES['imagename']['size'] < 2000000) {
            
            // نقل الملف للمجلد المحدد
            if (move_uploaded_file($_FILES['imagename']['tmp_name'], $target_file)) {
                
                // جلب الـ product_id من جدول المنتجات
                $selectId = $conn->prepare("SELECT id FROM products ORDER BY id DESC LIMIT 1");
                $selectId->execute();
                $resultId = $selectId->get_result();
                $res = $resultId->fetch_array();
                $product_id = $res['id'];
                
                // إضافة اسم الصورة ومعرّف المنتج لقاعدة البيانات
                $insert = "INSERT INTO images (imagename, product_id) VALUES ('$images_nm', '$product_id')";
                $query = $conn->query($insert);

                if ($query) {
                    echo "Image uploaded and saved in the database successfully.";
                    header("location: products.php");
                    exit();
                } else {
                    echo "Error: " . $conn->error;
                }
                
            } else {
                echo "Failed to upload the file.";
            }
            
        } else {
            echo "File is too big.";
        }
        
    } else {
        echo "Invalid file extension.";
    }
}
?>
*/

?> 