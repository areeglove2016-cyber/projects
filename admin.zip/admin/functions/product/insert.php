<?php
   
include "../connect.php";
$name=$_POST['name'];
$price=$_POST['price'];
$sale=$_POST['sale'];
$desciption=$_POST['desciption'];
$cat=$_POST['cat_id'];


$insert= "INSERT INTO products
    ( name , price , sale , desciption , cat_id) 
     VALUES 
    ('$name','$price','$sale','$desciption','$cat')";



if($conn-> query($insert)){
    $last_id = $conn->insert_id;
   include "images.php";  
    header('location:../../products.php');
}else{
    echo $conn-> error;
}




?>