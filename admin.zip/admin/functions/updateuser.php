<?php
if($_SERVER["REQUEST_METHOD"] != "POST"){
    header('location:../users.php');
    exit();
}
include "connect.php";
$id =$_POST['id'];
$user=$_POST['username'];
$email=$_POST['email'];
$address=$_POST['address'];
$gen=$_POST['gender'];
// $priv=$_POST['priv'];

// password
if(!empty($_POST['password'])){
    $pass=$_POST['password'];
   $uppass= "UPDATE users SET password='$pass' WHERE  id=$id ";
   $query = $conn -> query($uppass);
}
// end password
$update= "UPDATE users SET
username = '$user', email ='$email', address ='$address',
gender ='$gen' WHERE  id=$id " ;
   $query = $conn -> query($update);
   if($query){
    header('location:../users.php');
}else{
    echo $conn-> error ;
}
