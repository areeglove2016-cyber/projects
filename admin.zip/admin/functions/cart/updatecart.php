<?php
if($_SERVER["REQUEST_METHOD"] != "POST"){
    header('location:../../products.php');
    exit();
}
include "../connect.php";
$id =$_POST['id'];
$name=$_POST['name'];
$price=$_POST['price'];
$quantity=$_POST['quantity'];
$total=$_POST['total'];
if(empty($_FILES['img']['tmp_name'])&&($_POST['img']))
{
    $img=$_POST['img'];
    $extension=['jpg','png','gif','jpeg'];
    $ext=pathinfo($img,PATHINFO_EXTENSION);
    if(in_array($ext,$extension))
    {
        if($_FILES['img']['size']< 2000000){
            $img = uniqid(). ". ". $ext;
           move_uploaded_file(['img']['tmp_name'], "../../images/$img");
        }
    $upimg= "UPDATE products SET img='$img' WHERE  id=$id ";
          $query = $conn -> query( $upimg);
   
        }
}   
$update= "UPDATE carts SET
name = '$name', price ='$price',quantity='$quantity',total=$total WHERE  id=$id " ;
   $query = $conn -> query($update);
   if($query){
    header('location:../../cart.php');
}else{
    echo $conn-> error ;
}