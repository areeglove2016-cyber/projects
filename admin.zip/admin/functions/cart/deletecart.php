<?php
include "../connect.php";
 echo $id=$_GET['id'];
$del="DELETE FROM carts WHERE id=$id"; 
$query = $conn -> query($del);
if($query){
    header('location:../../cart.php');
}else{
    echo $conn-> error ;
}
?>