<?php
$name=$_POST['name'];
$price=$_POST['price'];
$quantity=$_POST['quantity'];
$total=$_POST['total'];
$imgname=$_FILES['img']['name'];
$temp=$_FILES['img']['tmp_name'];
if($_FILES['img']['error']== 0){

    $extension=['jpg','png','gif','jpeg'];
    $ext=pathinfo($imgname,PATHINFO_EXTENSION);
    if(in_array($ext,$extension))
    {
        if($_FILES['img']['size']< 2000000){
            $newimgname = uniqid(). ". ". $ext;
           move_uploaded_file($temp, "../../images/$newimgname");
        }else{
            echo"the file is big";
            exit();
                }
    }else{
        echo "wrong extension ";
        exit();
    }
}else{
    echo "upload the image, please :)";
    exit();
}


include "../connect.php";
$insertca= "INSERT INTO carts
    ( name , price , quantity , total , img) 
     VALUES 
    ('$name','$price', '$quantity','$total', '$newimgname')";
if($conn-> query($insertca)){
    header('location:../../cart.php');
}else{
    echo $conn-> error;
}