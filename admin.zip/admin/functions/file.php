<?php
$imgname=$_FILES['img']['name'];
$temp=$_FILES['img']['tmp_name'];

if($_FILES['img']['error']== 0){

    $div = explode(' ', $imgname);
    $file_ext = strtolower(end($div));
    $unique_image = md5(time()).'.'.$file_ext;
    $uploaded_image = "../../images/".$unique_image;
    $extension=['jpg','png','gif','jpeg'];
    // $ext=pathinfo($imgname,PATHINFO_EXTENSION);
    if(in_array($file_ext,$extension) === false)
    {
        echo "<span class='error'>You can upload only:-".implode(' .', $extension)."</span>";
        if($_FILES['img']['size']< 1048567){
        //    $uploaded_imag = uniqid(). ". ". $ext;
           move_uploaded_file($temp, "../../images/$uploaded_image");
        }else{
            echo"the file is big";
            exit();
                }
    }else{
        echo "wrong extension ";
        exit();
    }
}else{
    echo "upload the image, please :)";
    exit();
}
?>
<!-- // $i=0;
// foreach($_FILES['img']['name'] as $imgname){
//     $i++;
//     $imgname=$_FILES['img']['name'][$i];
//     $temp = $_FILES['img']['tmp_name'][$i];
//     $div = explode('.', $imgname);
//     $file_ext = strtolower(end($div));

//     print_r($unique_image);
//     exit();
//     // $uploaded_image = "../../images/".$unique_image;
 
//     $extension=['jpg','png','gif','jpeg'];
//     $ext=pathinfo($imgname,PATHINFO_EXTENSION);
//     if(in_array($ext, $extension)) {
   
//         //    move_uploaded_file($temp, "../../images/".$unique_image);
//         move_uploaded_file($temp, "../../images" . $unique_image);
//     }
//     $unique_image =time().rand(1,1000).'.'.$file_ext;
   
//         // if(($file_ext!='.png')&&($file_ext!='.jpg')&&($file_ext!='.jpeg')&&($file_ext!='.gif')){
            
//         // //
//         //     // $newimgname = uniqid(). ". ". $ext;
//         // }
    

// } -->

