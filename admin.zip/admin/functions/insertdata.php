<?php
if($_SERVER["REQUEST_METHOD"]!="POST"){
    header('location:../users.php');
    exit();
}
$user=$_POST['username'];
$pass=$_POST['password'];
$email=$_POST['email'];
$address=$_POST['address'];
$gen=$_POST['gender'];
// $priv=$_POST['priv'];
include "connect.php";
$insert= "INSERT INTO users
    ( username , password , email , address , gender) 
     VALUES 
    ('$user','$pass','$email','$address','$gen')";
    $query = $conn -> query($insert);
    if($query){
        header('location:../users.php');
    }else{
        echo $conn-> error ;
    }

?>