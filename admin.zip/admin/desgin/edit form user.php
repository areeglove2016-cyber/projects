<?php
$id =$_GET['id'];
include "functions/connect.php";
$select="SELECT * FROM users WHERE id = $id";
$query = $conn -> query($select);
$user = $query-> fetch_assoc();
?>
<form method="post" action="functions/updateuser.php">
    <input type="hidden" name="id" value="<?= $user['id']?>">
  <div class="form-group">
  <label for="exampleInputuser">username</label>
    <input type="username" name= "username" value="<?= $user['username']?>" class="form-control" id="exampleInputuser" aria-describedby="user Help">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input type="password" name= "password" class="form-control" id="exampleInputPassword1">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Email address</label>
    <input type="email" name= "email"  value="<?= $user['email']?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
  </div>
  <div class="form-group form-check">
    <input type="radio" class="form-check-input" id="exampleradio1" name="gender" value="0"
    <?= $user['gender'] == 0 ? 'checked':''?>
    >
    <label class="form-check-label" for="exampleradio1">Male</label>
  </div>
  <div class="form-group form-check">
    <input type="radio" class="form-check-input" id="exampleradio2" name="gender" value="1"
    <?= $user['gender'] == 1 ? 'checked':''?>
    >
    <label class="form-check-label" for="exampleradio2">famele</label>
  </div>
  <div class="form-group">
    <label for="exampleInputadress">address</label>
    <input name= "address" value="<?= $user['address']?>" type="adress" class="form-control" id="exampleInputaddress">
  </div>
  <!-- <div class="form-group">
    <label for="exampleInputprivliges">privliges</label>
    <select name= "priv" type="privliges" class="form-control" id="exampleInputprivliges">
      <option value="admin"
       $user['priv'] == 'owner'  ? 'selected':''
      >Admin</option>
      <option value="user"
       $user['priv'] == 'admin'  ? 'selected':''?>
      >user</option>
</select>
  </div> -->
  <button type="submit" class="btn btn-primary">Submit</button>
</form>