
<form method="post" action="functions/insertdata.php" >
  <div class="form-group">
  <label for="exampleInputuser">username</label>
    <input type="username" name= "username" class="form-control" id="exampleInputuser" aria-describedby="user Help">
  
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input type="password" name= "password" class="form-control" id="exampleInputPassword1"><br>
    
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Email address</label>
    <input type="email" name= "email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
  </div>
  <div class="form-group form-check">
    <input type="radio" class="form-check-input" id="exampleradio1" name="gender" value="0">
    <label class="form-check-label" for="exampleradio1">Male</label>
  </div>
  <div class="form-group form-check">
    <input type="radio" class="form-check-input" id="exampleradio2" name="gender" value="1">
    <label class="form-check-label" for="exampleradio2">famele</label>
  </div>
  <div class="form-group">
    <label for="exampleInputadress">address</label>
    <input name= "address" type="adress" class="form-control" id="exampleInputaddress">
  </div>
  <!-- <div class="form-group">
    <label for="exampleInputprivliges">privliges</label>
    <select name= "priv" type="privliges" class="form-control" id="exampleInputprivliges">
      <option value="owner">Owner</option>
      <option value="admin">Admin</option>
</select>
  </div> -->
  <button type="submit" class="btn btn-primary">Submit</button>
</form>