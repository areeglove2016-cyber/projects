
<?php
if ($_SESSION['priv'] == 'owner') {
	?>
<a class="btn btn-primary" href="?action=add">Add product</a>
<?php }?>
				<br>
				<br>
				<table class="table table-hover table-bordered table-striped">
					<thead>
						<tr>
							<th>id</th>
							<th>name</th>
							<th>price</th>
							<th>sale</th>
							<th>category</th>
							<th>image</th>
							<th>controlls</th>
						</tr>
					</thead>
                    <tbody>
                        <?php
                        include_once "functions/connect.php";
                        $selectpro="SELECT * FROM products ";
                        $querypro = $conn -> query($selectpro);
                        foreach($querypro as $product){
                       
                        ?>
                    <tr>
							<td><?= $product['id']?></td>
							<td><?= $product['name']?></td>
							<td><?= $product['price']?></td>
							<td><?= $product['sale']?></td>
						
							<td><?php
                            $catid=$product['cat_id'];
                            $selectcat="SELECT  name FROM categoris WHERE  id= $catid";
                            $querycat = $conn -> query($selectcat);
                            $category=$querycat->fetch_assoc();
                            echo $category['name'];
                            ?></td>
							 
								<td>
								<?php
								   include_once "functions/connect.php";
								   $pro_id=$product['id'];
								$imageresult = "SELECT * FROM images WHERE product_id= $pro_id"; 
								$queryimage = $conn -> query($imageresult);
									foreach($queryimage as $images){

						?>
							
							<img style='width:100px' src='images/<?=$images['imagename']?>'>
							<?php  } ?>
							</td>
							
					
							<td>
                                <div class="btn btn-group btn-group-sm">
								<?php
				  if ($_SESSION['priv'] == 'owner') {
				  ?>
                            <a  class="btn btn-primary"  href="?action=edit&id=<?= $product['id']?>">Edit</a>
                            <a  class="btn btn-danger" href="functions/product/deleteproduct.php?id=<?= $product['id']?>">Delete</a>
							<?php }?>
                            </div>
                            </td>
						</tr>
                        <?php }?>
                    </tbody>
				</table>