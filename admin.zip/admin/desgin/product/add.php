<?php
if(isset($_POST['upload'])){
  $upload[] = ($_FILES['imagename']['name']);
  print_r($upload);
}
?>
<form method="post" action="functions/product/insert.php" enctype="multipart/form-data">
  <div class="form-group">
  <label for="exampleInputname">name</label>
    <input type="name" name= "name" class="form-control" id="exampleInputname" aria-describedby="nameproduct">
  </div>
  
  <div class="form-group">
    <label for="exampleInputprice">price</label>
    <input type="text" name= "price" class="form-control" id="exampleInputprice" aria-describedby="priceHelp">
  </div>
  
  <div class="form-group">
    <label for="exampleInputsale">sale</label>
    <input name= "sale" type="text" class="form-control" id="exampleInputsale">
  </div>
  <div class="form-group">
    <label for="exampleInputimage">image</label>
    <?php
       include_once "functions/connect.php";
       $selectimg="SELECT * FROM images ";
       $queryimg = $conn -> query( $selectimg);
       $img_fetch= $queryimg ->fetch_assoc();
       ?>
    <input name= "imagename[]" type="file" class="form-control" id="exampleInputimage" multiple="multiple" required value="<?= $img_fetch['product_id']?>">
  </div>
  <div class="form-group">
    <label for="exampleFormControldesciption">desciption </label>
    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="desciption"></textarea>
  </div>
  <div class="form-group">
    <label for="exampleInputprivliges">category</label>
    <select name= "cat_id"  class="form-control" >
      <?php
       include_once "functions/connect.php";
       $selectcatg="SELECT * FROM categoris ";
       $querycatg = $conn -> query($selectcatg);
       foreach( $querycatg as $cat){
      ?>
      <option value="<?= $cat['id']?>"><?= $cat['name']?></option>
     <?php }?>
</select>
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>