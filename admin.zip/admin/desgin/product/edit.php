<?php
$id =$_GET['id'];
include "functions/connect.php";
$select="SELECT * FROM products WHERE id = $id";
$query = $conn -> query($select);
$product = $query-> fetch_assoc();

?>
<form method="post" action="functions/product/updatepro.php">
    <input type="hidden" name="id" value="<?= $product['id']?>">
  <div class="form-group">
  <label for="exampleInputname">name</label>
    <input type="name" name= "name" value="<?= $product['name']?>" class="form-control" id="exampleInputname" aria-describedby="name Help">
  </div>
  <div class="form-group">
    <label for="exampleInputprice1">price</label>
    <input type="text" name= "price"  value="<?= $product['price']?>" class="form-control" id="exampleInputPrice">
  </div>
  <div class="form-group">
    <label for="exampleInputsale">sale</label>
    <input type="text" name= "sale"  value="<?= $product['sale']?>" class="form-control" id="exampleInputsale" aria-describedby="saleHelp">
  </div>
  <div class="form-group">
    <label for="exampleInputimage">image</label>
    <input name= "images[]" type="file" value="" class="form-control" id="exampleInputimage">
  </div>
  <div class="form-group">
    <label for="exampleFormControldesciption">desciption </label>
    <textarea class="form-control"  value="<?= $product['desciption']?>" id="exampleFormControlTextarea1" rows="3" name="desciption"></textarea>
  </div>
  <div class="form-group">
    <label for="exampleInputprivliges">category</label>
    <select name= "cat_id"  class="form-control" >
      <?php
       include "functions/connect.php";
       $selectcatg="SELECT * FROM categoris ";
       $querycatg = $conn -> query($selectcatg);
       foreach( $querycatg as $cat){
      ?>
      <option value="<?= $cat['id']?>"><?= $cat['name']?></option>
     <?php }?>
</select>
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>