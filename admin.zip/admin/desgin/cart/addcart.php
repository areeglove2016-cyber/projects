<form method="post" action="functions/cart/insertcart.php" enctype="multipart/form-data">
  <div class="form-group">
  <label for="exampleInputname">name</label>
    <input type="name" name= "name" class="form-control" id="exampleInputuser" aria-describedby="name Help">
  </div>
  <div class="form-group">
    <label for="exampleInputimage">image</label>
    <input name= "img" type="file" class="form-control" id="exampleInputimage">
  </div>
  <div class="form-group">
    <label for="exampleInputprice">price</label>
    <input type="text" name= "price" class="form-control" id="exampleInputprice1" aria-describedby="priceHelp">
  </div>
  <div class="form-group">
    <label for="exampleInputprice">quantity</label>
    <input type="text" name= "quantity" class="form-control" id="exampleInputquantity" aria-describedby="quantityHelp">
  </div>
  <div class="form-group">
    <label for="exampleInputprice">total</label>
    <input type="text" name= "total" class="form-control" id="exampleInputprice1" aria-describedby="priceHelp">
  </div>

  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>