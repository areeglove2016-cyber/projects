<?php
if ($_SESSION['priv'] == 'owner') {
	?>
<a class="btn btn-primary" href="?action=add">Add cart</a>
<?php }?>
				<br>
				<br>
				<table class="table table-hover table-bordered table-striped">
					<thead>
						<tr>
							<th>id</th>
							<th>name</th>
							<th>image</th>
                            <th>price</th>
                            <th>quantity</th>
                            <th>total</th>
                            <th>controlls</th>
						</tr>
					</thead>
                    <tbody>
                        <?php
                        include "functions/connect.php";
                        $selectcart="SELECT * FROM carts ";
                        $querycart= $conn -> query($selectcart);
                        foreach($querycart as $cart){
                       
                        ?>
                    <tr>
							<td><?= $cart['id']?></td>
							<td><?= $cart['name']?></td>
							<td><img style='width:100px' src="images/<?= $cart['img']?>"></td>
                            <td><?= $cart['price']?></td>
                            <td><?= $cart['quantity']?></td>
                            <td><?= $cart['total']?></td>
                            <td>
                                <div class="btn btn-group btn-group-sm">
                                <?php
				  if ($_SESSION['priv'] == 'owner') {
				  ?>
                            <a  class="btn btn-primary"  href="?action=edit&id=<?= $cart['id']?>">Edit</a>
                            <a  class="btn btn-danger" href="functions/cart/deletecart.php?id=<?= $cart['id']?>">Delete</a>
                            <?php }?>
                            </div>
                            </td>
						</tr>
                        <?php }?>
                    </tbody>
				
				</table>