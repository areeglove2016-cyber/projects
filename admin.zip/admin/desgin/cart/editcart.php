<?php
$id =$_GET['id'];
include "functions/connect.php";
$select="SELECT * FROM carts WHERE id = $id";
$query = $conn -> query($select);
$cart = $query-> fetch_assoc();
?>
<form method="post" action="functions/cart/updatecart.php">
    <input type="hidden" name="id" value="<?= $cart['id']?>">
  <div class="form-group">
  <label for="exampleInputname">name</label>
    <input type="name" name= "name" value="<?= $cart['name']?>" class="form-control" id="exampleInputname" aria-describedby="name Help">
  </div>
  <div class="form-group">
    <label for="exampleInputprice1">price</label>
    <input type="text" name= "price"  value="<?= $cart['price']?>" class="form-control" id="exampleInputPrice">
  </div>
  <div class="form-group">
    <label for="exampleInputimage">image</label>
    <input name= "img" type="file" value="<?= $cart['img']?>" class="form-control" id="exampleInputimage">
  </div>
  <div class="form-group">
    <label for="exampleInputprice">quantity</label>
    <input type="text" name= "quantity" value="<?= $cart['quantity']?>" class="form-control" id="exampleInputquantity" aria-describedby="quantityHelp">
  </div>
  <div class="form-group">
    <label for="exampleInputprice">total</label>
    <input type="text" name= "total"  value="<?= $cart['total']?>"class="form-control" id="exampleInputprice1" aria-describedby="priceHelp">
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>