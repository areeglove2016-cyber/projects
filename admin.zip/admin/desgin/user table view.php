<!-- 
if ($_SESSION['priv'] == 'owner') {
	?> 
	 }?> -->
<a class="btn btn-primary" href="?action=add">Add user</a>

				<br>
				<br>
				<table class="table table-hover table-bordered table-striped">
					<thead>
						<tr>
							<th>id</th>
							<th>username</th>
							<th>email</th>
							<th>address</th>
							<th>gender</th>
							<th>
								
								controlls 
							</th>
						</tr>
					</thead>
					<tbody>
						<?php
						include_once "functions/connect.php";
						$select ="SELECT * FROM users";
						$query = $conn -> query($select);
						foreach($query as $user){
						?>
						<tr>
							<td><?= $user['id']?></td>
							<td><?= $user['username']?></td>
							<td><?= $user['email']?></td>
							<td><?= $user['address']?></td>
							<td><?php
							if( $user['gender'] == 0){
								echo"male";
							}else{
								echo"female";
							}
							?></td>
							<!-- <td $user['priv'] =='owner' ?'owner' : 'admin'?></td>
							<td>
                  
				  if ($_SESSION['priv'] == 'owner') {
				  ?> -->
									<a href="?action=edit&id=<?= $user['id']?>"><button  class="btn btn-primary" >Edit</button></a>
							
<button type="button" class="btn btn-danger" data-toggle="modal" data-target="#<?= $user['id']?>">
Delete
</button>
 <!-- }?> -->
<!-- Modal -->
<div class="modal fade" id="<?= $user['id']?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       you want to delete <span class="text-danger"><b><?= $user['username']?></b></span>  are sure :)
	      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <a  class="btn btn-danger" href="functions/delete_user.php?id=<?= $user['id']?>">Confirm</a>
	      </div>
    </div>
	
  </div>
</div>			
	</td>
							</tr>
					<?php } ?>
					</tbody>
				</table>