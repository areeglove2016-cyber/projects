<!DOCTYPE html>
<html lang="en">
<head>
	<title>Login V4</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
  <body>
  <div class="limiter">
		<div class="container-login100" style="background-image: url('images/bg-01.jpg');">
			<div class="wrap-login100  p-l-55 p-r-55 p-t-65 p-b-54">
               <form method="post" class="login100-form validate-form" action="function/insertregister.php" >
               <span class="login100-form-title p-b-49">
						register
					</span>
          <div class="wrap-input100 validate-input m-b-23" data-validate = "Username is reauired">
          <span class="span-input100">Username</span>
                  <input class="input100"  id="inputusername" type="text" name= "username" placeholder="enter your username">
                  <span class="focus-input100" data-symbol="&#xf206;"></span>
                </div>
              <div  class="wrap-input100 validate-input m-b-23" data-validate = "passwordis reauired">
                <span class="span-input100">Password</span>
                  <input class="input100"  name= "password" id="inputPassword3" type="password" placeholder="enter your password">
                  <span class="focus-input100" data-symbol="&#xf206;"></span>
                </div>
              <div class="wrap-input100 validate-input m-b-23" data-validate = "email is reauired">
              <span class="span-input100">email</span>
                  <input class="input100" name= "email" id="inputEmail3" type="email" placeholder=" enter your Email">
                  <span class="focus-input100" data-symbol="&#xf206;"></span>
                </div>
            
              <div class="wrap-input100 validate-input m-b-23" data-validate = "address is reauired">
              <span class="span-input100">address</span>
                  <input class="input100" id="inputaddress" name= "address"  type="text" placeholder=" enter your address">
                </div>
           
              <fieldset class="form-group">
                  <legend class="col-form-span col-sm-2 pt-0">gender</legend>
                    <div class="form-check">
                      <input class="form-check-input" id="gridRadios1" type="radio" name="gender" value="0" checked="">
                      <span class="form-check-span"  for="gridRadios1">male</span>
                    </div>
                    <div class="form-check">
                      <input class="form-check-input" id="gridRadios2" type="radio" name="gender" value="1">
                      <span class="form-check-span" for="gridRadios2">famle</span>
                    </div>
              </fieldset>
              <div class="container-login100-form-btn">
						<div class="wrap-login100-form-btn">
							<div class="login100-form-bgbtn"></div>
							<button class="login100-form-btn" type="submit">
							register
							</button></a>
						</div>
					</div>
			</div>      
</form>
</div>
</div>
</div>
   <!-- JavaScript files-->
   <script src="vendor/jquery/jquery.min.js"></script>
      <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
      <script src="vendor/lightbox2/js/lightbox.min.js"></script>
      <script src="vendor/nouislider/nouislider.min.js"></script>
      <script src="vendor/bootstrap-select/js/bootstrap-select.min.js"></script>
      <script src="vendor/owl.carousel2/owl.carousel.min.js"></script>
      <script src="vendor/owl.carousel2.thumbs/owl.carousel2.thumbs.min.js"></script>
      <script src="js/front.js"></script>
      <script>
        // ------------------------------------------------------- //
        //   Inject SVG Sprite - 
        //   see more here 
        //   https://css-tricks.com/ajaxing-svg-sprite/
        // ------------------------------------------------------ //
        function injectSvgSprite(path) {
        
            var ajax = new XMLHttpRequest();
            ajax.open("GET", path, true);
            ajax.send();
            ajax.onload = function(e) {
            var div = document.createElement("div");
            div.className = 'd-none';
            div.innerHTML = ajax.responseText;
            document.body.insertBefore(div, document.body.childNodes[0]);
            }
        }
        // this is set to BootstrapTemple website as you cannot 
        // inject local SVG sprite (using only 'icons/orion-svg-sprite.svg' path)
        // while using file:// protocol
        // pls don't forget to change to your domain :)
        injectSvgSprite('https://bootstraptemple.com/files/icons/orion-svg-sprite.svg'); 
        
      </script>
      <!-- FontAwesome CSS - loading as last, so it doesn't block rendering-->
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    </div>
  </body>
  </html>