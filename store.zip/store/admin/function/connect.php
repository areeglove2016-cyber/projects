<?php
define('HOST','localhost');
define('USER','root');
define('PASS','');
define('DBNAME','pop_project');
$conn = new mysqli(HOST , USER , PASS ,DBNAME);
$querys = "SELECT id,imagename,product_id FROM images";
  $result = mysqli_query($conn, $querys);
  $row= mysqli_fetch_assoc($result);
$conn-> set_charset('utf8');