<?php
include "connect.php";
session_start();

	if(!isset($_SESSION['loginid'])){
	
    die("Please log in to add products to your cart.");
}
$product_id = isset($_POST['product_id']) ? (int)$_POST['product_id'] : 0;
$user_id = isset($_SESSION['loginid']) ? (int)$_SESSION['loginid'] : 0;

if ($product_id > 0 && $user_id > 0) {
    $cartcheck= "SELECT * FROM carts WHERE user_id = $user_id AND product_id =$product_id";
    $carts = $conn->query($cartcheck);
if($carts){
    if ($carts->num_rows > 0) {
        $cartitem = $carts->fetch_assoc();
    $newquantity = $cartitem['quantity'] + 1;
        
        $cartupdate = "UPDATE carts SET quantity = '$newquantity ' WHERE user_id = ' $user_id' AND product_id = '$product_id '";
        $updatecarts = $conn->query($cartupdate);
      if($updatecarts){
      }
    } else {
        $quantity = 1;
        $cartinsert = "INSERT INTO carts (user_id, product_id, quantity) VALUES ('$user_id','$product_id','$quantity')";
        $insertcarts = $conn->query($cartinsert);
        if($insertcarts){

        }
    }
 
}
      header("Location:../cart.php");
    exit();
}

?>
