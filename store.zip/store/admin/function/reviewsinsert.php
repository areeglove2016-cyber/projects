<?php
include "connect.php";
session_start();
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $product_id = $_POST['product_id'];
    $user_id = $_SESSION['loginid'];
    $rating = $_POST['rating'];
    $comment = $_POST['comment'];
    $reviewdate = $_POST['reviewdata'];
    $queryreview = "INSERT INTO reviews (product_id, user_id, rating, comment, reviewdata) 
              VALUES ('$product_id', '$user_id', '$rating', '$comment','  $reviewdate')";
      $reviews = $conn->query($queryreview);
    if ($reviews) {
      $selectUser = "SELECT username FROM users WHERE id = '$user_id'";
      $userResult = $conn->query($selectUser);
      $user = $userResult->fetch_assoc();
      echo json_encode([
        'status' => 'success',
        'username' => $user['username'],
        'reviewdata' => $reviewdate,
        'rating' => $rating,
        'comment' => $comment
    ]);
} else {
 
$conn-> error;
}
}