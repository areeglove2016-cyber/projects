<?php
if($_SERVER["REQUEST_METHOD"]!="POST"){
    header('location:../login.php');
    exit();
}
$user=$_POST['username'];
$pass=$_POST['password'];
$email=$_POST['email'];
$address=$_POST['address'];
$gen=$_POST['gender'];
include "connect.php";
$insert= "INSERT INTO users
    ( username , password , email , address , gender) 
     VALUES 
    ('$user','$pass','$email','$address','$gen')";
    $query = $conn -> query($insert);
    if($query){
        header('location:../index.php');
    }else{
        echo $conn-> error ;
    }

?>