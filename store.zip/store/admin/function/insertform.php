<?php
include "connect.php";
$username=$_POST['username'];
$password=$_POST['password'];
$email=$_POST['email'];
$insertdata="INSERT INTO user
( username , password , email ) 
 VALUES 
('$username','$password','$email')";
  $query = $conn -> query($insertdata);
  if($query){
    $last_id = $conn->insert_id;
    echo'<div class="dataform"><table class="table">
  <thead>
    <tr>
      <th scope="col">id</th>
      <th scope="col">username</th>
      <th scope="col">password</th>
      <th scope="col">email</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>'. $last_id .'</td>
      <td>' . $username . '</td>
      <td>' . $password . '</td>
      <td>' . $email . '</td>
    </tr>
  </tbody>
</table> 
</div>';
  }else{
    echo $conn-> error ;
}