<?php
include "connect.php";
session_start();
if (!isset($_SESSION['loginid'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['loginid'];

if (isset($_GET['product_id'])) {
    $product_id = $_GET['product_id'];
    
$cartdel = "DELETE FROM carts WHERE user_id =$user_id AND product_id = $product_id";
$deletecart = $conn->query($cartdel);
if ($deletecart) {
    header("Location:../cart.php");
    exit();
} else {
    echo $conn-> error ;
}
}

?>
