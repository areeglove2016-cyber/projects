<?php
session_start();
include 'connect.php'; 

if (isset($_POST['product_id']) && isset($_POST['quantity']) && isset($_SESSION['loginid'])) {
  $product_id = $_POST['product_id'];
  $quantity = $_POST['quantity'];
  $user_id = $_SESSION['loginid'];

  $sqlcart = "UPDATE carts SET quantity = '$quantity' WHERE user_id = '$user_id' AND product_id = '$product_id' ";
  $updatecart = $conn -> query($sqlcart);

  if ($updatecart) {
  $sqlca = "SELECT p.price FROM products AS p WHERE p.id = $product_id ";
  $selcart = $conn -> query($sqlca);
  $seca = $selcart-> fetch_assoc();
  $price = $seca['price']; 
  $total = $price * $quantity;


  $sqlsum = "SELECT SUM(p.price * c.quantity) AS carttotal FROM carts AS c 
  JOIN products AS p ON c.product_id = p.id WHERE c.user_id = $user_id";
  $sumcart = $conn -> query($sqlsum);
  $sumca =  $sumcart-> fetch_assoc();
  $carttotal = $sumca['carttotal'];
 
  echo json_encode([
    'total' => $total,
    'cartTotal' => $carttotal
  ]);
}
}
?>
