<?php
session_start();
include "connect.php";

$user=$_POST['username'];
$pass=$_POST['password'];
$check = "SELECT * FROM users WHERE  username='$user' AND password='$pass' ";
$query = $conn -> query($check);
 if($query -> num_rows > 0){
    $user = $query-> fetch_assoc();
    $_SESSION['loginid']=$user['id'];
    header('location:../cart.php');
 }else{
    $_SESSION['loginerror']="<div class='alert alert-danger'> uncorrect login </div>";
    header('location:../login.php');
     exit();
 }
?>