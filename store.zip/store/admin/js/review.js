
$("#addreviewbtn").click(function() {
    $("#reviewformcontainer").show(); 
});
    $("#reviewform").submit(function(e) {
        e.preventDefault();
        var data={};
        $('#reviewform input ,textarea ,select').each(function ( index , input){
            data[$(input).attr('name')]=$(input).val();
        });
         
         var currentdate = new Date();
         var formatteddate = currentdate.toISOString(); 
         data['reviewdata'] = formatteddate; 
 
        $.post('function/reviewsinsert.php', data ,function(data){
            var result = JSON.parse(data);
        
            if (result.status === 'success') {
                
                $('form input, form textarea').val('');
                $("#reviewformcontainer").hide();            
                var newReviewHtml = `
                  <div class="p-4 p-lg-5 bg-white">
                <div class="row">
                  <div class="col-lg-8">
                    <div class="media-body ml-3">
                        <h6 class="mb-0 text-uppercase">${result.username}</h6>
                        <p class="small text-muted mb-0 text-uppercase">${result.reviewdata}</p>
                        <ul class="list-inline mb-1 text-xs">
                            ${getStarsHtml(result.rating)}
                        </ul>
                        <p class="text-small mb-0 text-muted ">${result.comment}</p>
                    </div>
                    </div>
                    </div>
                    </div>
                `;
                $('#reviews').prepend(newReviewHtml); 
            } 
        });
    });
    
   
    function getStarsHtml(rating) {
        var starsHtml = '';
        for (var i = 0; i < Math.floor(rating); i++) {
            starsHtml += '<li class="list-inline-item m-0"><i class="fas fa-star text-warning"></i></li>';
        }
        if (rating % 1 != 0) {
            starsHtml += '<li class="list-inline-item m-0"><i class="fas fa-star-half-alt text-warning"></i></li>';
        }
        return starsHtml;
    }
        
   

