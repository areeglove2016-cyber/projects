$('.inc-btn').on('click', function(event) {
    event.preventDefault();
    // var quantityinput = $(this).closest('.quantity').querySelector('input');
    // var quantity = parseInt(quantityinput.val); 
    var quantityinput = $(this).closest('.quantity').find('input');
    var quantity = parseInt(quantityinput.val()); 
    
    // console.log(quantity);
    if (!isNaN(quantity)) {
        // =================== Solution ==============================
        // quantityinput.value = quantity +  1;

        // quantity += 1; 
        
        // =================== Anthor Solution =======================
        quantityinput.val(quantity);
        updatecart(quantityinput); 
} else {
    quantityinput.value = 1;
}
}); 
$('.dec-btn').on('click', function(event) {
    event.preventDefault();
    var quantityinput = $(this).closest('.quantity').find('input');
    var quantity = parseInt(quantityinput.val());
    if (!isNaN(quantity) && quantity > 1) {
        // =================== Solution ==============================
        // quantityinput.value = quantity - 1;
        
        // quantity -= 1;
        
        // =================== Anthor Solution =======================
        quantityinput.val(quantity);
        updatecart(quantityinput); 
    } else {
        quantityinput. value = 1;
    }
});

function updatecart(quantityinput) {
    var quantity = quantityinput.val();
    var product_id = quantityinput.closest('tr').data('product-id');

        var data = { product_id: product_id, quantity: quantity
        };
        $.post('function/updatecart.php', data ,function(dat){
            var updateddata = JSON.parse(dat);
            quantityinput.closest('tr').find('.total-price').text('$' + updateddata.total);
            $('#total-amount').text('$' + updateddata.cartTotal);
            console.log(product_id); 
        });
    }