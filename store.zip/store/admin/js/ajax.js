
var log=console.log;
$('.insertdata').submit(function(event){
    event.preventDefault();
    var data={};
    $('.insertdata input').each(function ( index , input){
        data[$(input).attr('name')]=$(input).val();
    })
$.post('function/insertform.php', data ,function(data){
    $('.dataform').append(data);
    $('form input').val();
    $('#productView').modal('hide');
    $('.modal-backdrop').css('opacity', 0);
})
})
  // $.post('function/insertform.php',{
    //      username : $('input[name="username"]').val(),
    //      password: $('input[name="password"]').val(),
    //     email : $('input[name="email"]').val()
    // },function(data){
    //     $('.dataform').append(data);
    //     log(data);
    // })
    // $.post('test2.php' , {
    //   username : $('input:first').val(),
    //  password : $('input:nth-child(2)').val(),
    //  email : $('input:last').val()
    // } , function(data){
    // $('.dataform').html(data);
    // });
   